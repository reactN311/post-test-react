import React, { useState } from 'react';

import useFetch from './useFetch'; 
import stylusLi, { listStylus, stylusUserAvatar } from './user-styles';
import { Post, PostsProp, UserProp } from './user-interface'; 
import './UserList.styles.css'


const urlBase:string = `http://jsonplaceholder.typicode.com/`
// const url = `http://jsonplaceholder.typicode.com/posts_limit=5`
// const urlUsers = `https://jsonplaceholder.typicode.com/users`



const User :React.FC<UserProp> = ({userName, name}:UserProp):JSX.Element => {
  return (<div className='user-avatar' style={stylusUserAvatar} >
            <div>{userName}</div>  
            <div>({name})</div>  
          </div>)
}
const Posts :React.FC<PostsProp> = ({title, body}:PostsProp):JSX.Element => {
  return (<div className='user-avatar' style={stylusUserAvatar} >
            <div style={{color:'grey'}}>{title}</div>
            <div>{body}</div>
          </div>)
}

const UserList:React.FC = () => {
  const [searchPost, setSearchPost] = useState<string>('') 
  const posts  = useFetch(urlBase)
 
  let handlerInput = (e: React.ChangeEvent<HTMLInputElement>) => { 
    var element = e.target as HTMLInputElement;   
    setSearchPost(element.value)
  }
 
  return posts.data ? (
    <div className='wrap-list'style={stylusUserAvatar} >
      <input type='text' defaultValue={searchPost} onChange={handlerInput} /> 
      <ul style={listStylus} >
        {posts.data
        .filter(p => p.body.includes(searchPost))
        .map(render)}
      </ul>
    </div>
  )
  :(<div>...loading</div>)

  function render (el: Post, i: number) {
    return (<li key={i}   style={stylusLi} > 
              <User userName={el.userData && el.userData.un} name={el.userData && el.userData.nm}  /> 
              <Posts title={el.title} body={el.body}  />
            </li>)
  }
 
}

// function areEqual(prevProps: any, nextProps: any) {

//   if(prevProps === nextProps) {
//     console.log(true);
//     return true
//   }else {
//     console.log(false);
//     return false
//   }

// }
// export default React.memo(UserList, areEqual);
export default React.memo(UserList);
 