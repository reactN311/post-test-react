// let str: string = 'Hi, Mark'

// console.log(str);
///////////////////////////////

// class Animal {
//   protected voice: string = ''
//   public color: string = 'black'
//   constructor(){this.print()}
//   private print(): void{
//     console.log('Start class');
//   }
// }

// class Cat extends Animal {
//   public setVoice(voice: string): void{
//     this.voice = voice
//   }
// }

// const cat = new Cat()
// cat.setVoice('myau')
// console.log(cat.color);

///////////////////////////////

// abstract class Component {
//   abstract render(): void
//   abstract info(): string

//   constructor() { }
// }

// class AppComponent extends Component {
//   constructor(private infoApp: string) { super() }

//   render(): void{ console.log('div') }

//   info(): string{ return this.infoApp }
// }

// const app = new AppComponent('app-comp');
// console.log(app.info())

//////////// Generic ///////////////////
// const arOfNumbers: Array<number> = [1,1,2,3,5]
// const arOfStrings: Array<string> = ['1','1','2','3','5']

// function reverse<T>(arr: Array<T>): Array<T> {
//   return arr.reverse()
// }

// reverse(arOfNumbers)
// reverse(arOfStrings)

////////////// /////////////////
// function identity<Type>(arg: Type): Type {
//   return arg;
// }

// let myIdentity: <Input>(arg: Input) => Input = identity;

//////////////Operation/////////////////
// interface Person {
//   name: string
//   age: number
// }

// type PersonKeys = keyof Person

// let keyPerson: PersonKeys = 'name'
// let keyPerson2: PersonKeys = 'age'

////////////// /////////////////
// type User = {
//   _id: number;
//   name: string;
//   email: string;
//   createdAt: Date;
// };

// type UserKeysNoIdNoCreact1 = Exclude<keyof User, "_id" | "createdAt">;
// type UserKeysNoIdNoCreact2 = Pick<User, "name" | "email">;

//////////////Factorial/////////////////
// var factiorial = function f(n: number): number {
//   return n ? n * f(n - 1) : 1;
// };

// var fac = factiorial;
// console.log(fac(5)); //120

//////////////Fibonaci/////////////////
// var i: number;
// var fib: Array<number> = []; // Initialize array!

// fib[0] = 0;
// fib[1] = 1;
// for (i = 2; i <= 10; i++) {
//   // Next fibonacci number = previous + one before previous
//   // Translated to JavaScript:
//   fib[i] = fib[i - 2] + fib[i - 1];
//   console.log(fib[i]);
// }

///////////////////////////////
// let x = 0, y = 1, i:number, z:number

// function fib(n:number):void {
//   console.log(x)
//   console.log(y)
//   for (i = 2; i <= 10; i++)
//   {

//       z = x + y;
//       x = y;
//       y = z;
//       console.log((x + y))

//   }
//   // console.log((x + y))
// }
// fib(10)

///////////////////////////////

// function fibonacci(n:number):number {
//     let res = n <  1 ? 0
//             : n <= 2 ? 1
//             : fibonacci(n - 1) + fibonacci(n - 2)

//     return res
// }

// console.log(fibonacci(10)); // 55

///////////////////////////////

// let fib = function(numMax:number){
//   let x:number
//   for(var fibArray = [0,1], i=0,j=1,k=2; k <= numMax;i=j,j=x,k++ ){
//       x=i+j;
//       fibArray.push(x);
//   }
//   console.log(fibArray);
// }

// fib(10)

//res [
//    0, 1,  1,  2,  3,
//    5, 8, 13, 21, 34,
//   55
// ]

///////////////////////////////
// var fib = [0, 1];
// for(var i=fib.length; i<=10; i++) {
//     fib[i] = fib[i-2] + fib[i-1];
// }
// console.log(fib);
//res [
//    0, 1,  1,  2,  3,
//    5, 8, 13, 21, 34,
//   55
// ]
///////////////////////////////

// function fib(n:number): number {
//     return n <= 1 ? n : fib(n - 1) + fib(n - 2);
// }

// fib(10); // returns 55

///-------------------------------
// const fib = (n:number): number => n <= 1 ? n : fib(n - 1) + fib(n - 2)

// console.log(fib(10)); //55
///---------------

// function fib(n:number): number[] {
//   let newArr = Array(n +1).fill(null).map((_,i,f) =>{
//     return i <= 1 ?  f[i] = i : f[i] = f[i -1] + f[i -2]
//   })
//   return newArr
//   // return n <= 1 ? n : fib(n - 1) + fib(n - 2);
// }

// console.log(fib(10));
// returns 55

///////////////////////////////
// let xam2 = 5;
// console.log(xam2.toPrecision(3));
// returns 5.00

///////////////////////////////
export const restMy = (a: string, ...res: Array<string>): string => {
  // console.log(a, ...res);
  return res.length ? a + res[0] : a;
  // return a + res[0];
};

console.log(restMy("aMy", "resMy1")); // aMyresMy1

// ///////////////////////////////
// type resCont = () => string | number;
// const initState2 = 17;

// export const resContent = (a: string, ...res: Array<string>): resCont => {
//   const initState = 25;
//   return function (): string | number {
//     return res.length ? a + res[0] : initState + initState2;
//   };
// };
// let newRes = resContent("Natusya");
// console.log(newRes()); // 42

// ///////////////////////////////
// type resCont = () => string | number;
// type resFunc = string | number;
// const initState2 = 17;

// export const resContent = (a: string, ...res: Array<string>): resCont => {
//   const initState = 25;
//   return (): resFunc => {
//     return res.length ? a + res[0] : initState + initState2;
//   };
// };
// let newRes = resContent("Natusya");
// console.log(newRes()); // 42 //in 1.253 seconds

///////////////////////////////
// type resCont = () => string | number;
// type resFunc = string | number;
// const initState2 = 17;

// export function resContent(a: string, ...res: Array<string>): resCont {
//   const initState = 25;
//   return function (): resFunc {
//     return res.length ? a + res[0] : initState + initState2;
//   };
// }
// let newRes = resContent("Natusya");
// console.log(newRes()); // 42 //in 1.221 seconds

/////////////////////////////////////////////////

// var elements = ["Hydrogen", "Helium", "Lithium", "Beryllium"];

// let l = elements.map(({ length }) => length); // [8, 6, 7, 9]
// // let lSlice = elements.map((el) => el.slice(0, 1)); // [8, 6, 7, 9]
// let lSlice = elements.map(sl); // [8, 6, 7, 9]

// function sl(t: string, i: number) {
//   return { idx: i, header: t.slice(0, 1) };
// }

// console.log(l);
// console.log(lSlice);

//////////////
// let col2 = function redFunc(color) {
//   this.colorValue = color;
// };

// const redCar = new col2("red");

// console.log(redCar); // {colorValue: "red"}

//////////////////
// function myRegularFunction() {
//   const myArrowFunction = (...args) => {
//     console.log(args);
//   };

//   myArrowFunction("c", "d");
// }

// myRegularFunction("a", "b"); // ["c", "d"]
//////////////

// function map<Input, Output>(arr: Input[], func: (arg: Input) => Output): Output[] {
//   return arr.map(func);
// }

// // Parameter 'n' is of type 'string'
// // 'parsed' is of type 'number[]'
// const parsed = map(["1", "2", "3"], (n) => parseInt(n));
