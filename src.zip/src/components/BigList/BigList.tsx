import React, { useState } from 'react';
import CSS from 'csstype';
import './BigList.styles.css'
import useFetch from '../../hooks/useFetch';
import useHover from '../../hooks/useHover';

interface Post {
  userId: number
  id: number
  title: string
  body: string
}
const url = `http://jsonplaceholder.typicode.com/posts`

const stylusLi = {
  minHeight: '20%',
  alignItems: 'center',
  display: 'flex',
}

const BigList = () => {
  const [mR, setMr] = useState<string>('')
  const [page, setPage] = useState<number>(0)

  console.log('rerender Big');
  

  const hoverRef = React.useRef(null)
  const isHover = useHover(hoverRef)

  let handlerLi = (e: React.MouseEvent<HTMLLIElement, MouseEvent>) => { 
    var element = e.target as HTMLElement;  
    console.log('e.target, e.pageY',element.id, e.pageY, element.offsetTop) 
  }

  let handlerUlScroll = (e: React.MouseEvent<HTMLUListElement, MouseEvent>) => { 
    var element = e.target as HTMLUListElement;  
    let top = element.scrollTop
    // let top = element.closest('ul').scrollTop 
    if(top > 123){
      // setMr('124')
      setPage(prev => prev + 15)
    }else if(top === 1){
      setPage(prev => prev >= 15 && prev - 15)
      // setMr(`${top.toFixed(0)}`)
    }
    console.log('element.scrollTop, offsetTop',  element.scrollTop.toFixed(0),  element.offsetTop ) 
  }
  
  // const { status, data, error } = useFetch<Post[]>(url)
  // console.log({ status, data, error })
  
  const listStylus: CSS.Properties = {
    'maxHeight': '120px',
    'overflow': 'scroll',
  }  
  let newArr = Array(60).fill(null).map((_,i) => i)

  return (
    <div className='wrap-list' >
      {`The current div is ${isHover ? `hovered` : `unhovered`} ${mR}`}
      <ul style={listStylus} onScroll={handlerUlScroll} >
        {newArr.filter((_, i) => i > page && i < (page + 15)).map((el, i) => <li key={Date.toString()}  id={`${i}`} onClick={handlerLi} style={stylusLi} >Item element {el}</li>)}
      </ul>
    </div>
  )
}

function areEqual(prevProps, nextProps) {

  if(prevProps === nextProps) {
    console.log(true);
    return true
  }else {
    console.log(false);
    return false
  }

  /*
  возвращает true, если nextProps рендерит
  тот же результат что и prevProps,
  иначе возвращает false
  */
}
export default React.memo(BigList, areEqual);
 